// task 1

const wishes = ["Hello!", "How are you?", "Hi, guys!"];

alert(wishes[0]);

// task 2

const robotFirst = {name:"Roby", color:"orange", type:"male, female"};

const robotSecond = {name:"Ruby", color:"pink", type:"male, female"};

let frase = `Hello, ${robotSecond.name}!`;

console.log(frase) 